import React, { useState } from 'react';
import { toast } from 'sonner';
import { Download, KeyRound, Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import RelayList from '@/components/RelayList';
import SourceTestResults from '@/components/SourceTestResults';
import { getSettings, saveSettings, testSources, relayFileUrl, getStatus } from '@/api/zt';

const inputCls = 'w-full px-3 py-2 rounded-lg bg-[#0b0e14] border border-[#263042] text-[#f8fafc] text-xs font-mono placeholder-[#64748b] focus:outline-none focus:border-[#3b82f6]';
const btnCls = 'px-4 py-2 rounded-lg text-xs font-semibold transition-colors disabled:opacity-50 flex items-center gap-1.5';
const errMsg = (e) => e?.response?.data?.detail || e.message;

export default function SourcesDialog({ open, onOpenChange }) {
  const [adminKey, setAdminKey] = useState(localStorage.getItem('zt_admin_key') || '');
  const [settings, setSettings] = useState(null);
  const [busy, setBusy] = useState('');
  const [testResults, setTestResults] = useState(null);
  const [runtimeStatus, setRuntimeStatus] = useState(null);

  React.useEffect(() => {
    if (!open) return;
    getStatus().then(setRuntimeStatus).catch(() => setRuntimeStatus({ error: 'Statut indisponible' }));
  }, [open]);

  const run = async (name, fn) => {
    setBusy(name);
    try { await fn(); } catch (e) { toast.error(errMsg(e)); } finally { setBusy(''); }
  };

  const unlock = () => run('load', async () => {
    const s = await getSettings(adminKey);
    localStorage.setItem('zt_admin_key', adminKey);
    setSettings(s);
  });

  const save = () => run('save', async () => {
    await saveSettings(adminKey, settings);
    setRuntimeStatus(await getStatus());
    toast.success('Sources enregistrées');
  });

  const test = () => run('test', async () => {
    await saveSettings(adminKey, settings);
    setTestResults((await testSources(adminKey)).results);
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent data-testid="sources-dialog" className="bg-[#11151f] border-[#263042] text-[#f8fafc] max-w-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Sources de récupération</DialogTitle>
          <DialogDescription className="text-[#64748b] text-xs">
            Le .org bloque les IP de datacenter. Ajoute un relais tournant sur une IP résidentielle (ton PC + tunnel gratuit) ou une clé ScraperAPI.
          </DialogDescription>
        </DialogHeader>

        <section className="rounded-lg border border-[#263042] bg-[#0b0e14] p-3 space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-[#94a3b8]">Diagnostic du déploiement</h3>
            <span className={`text-[10px] ${runtimeStatus?.error ? 'text-amber-400' : 'text-emerald-400'}`}>
              {runtimeStatus?.error ? 'indisponible' : 'connecté'}
            </span>
          </div>
          <div className="grid gap-1 text-xs text-[#cbd5e1]">
            <div><span className="text-[#64748b]">URL API :</span> <code>{window.location.origin}/api</code></div>
            <div><span className="text-[#64748b]">Page :</span> <code>{window.location.pathname}</code></div>
            <div><span className="text-[#64748b]">Relais configurés :</span> {runtimeStatus?.relays?.length ?? '—'}</div>
            <div><span className="text-[#64748b]">ScraperAPI :</span> {runtimeStatus?.scraperapi ? 'configurée' : 'non configurée'}</div>
            <div><span className="text-[#64748b]">Connexion directe :</span> {runtimeStatus?.direct ? 'activée' : 'désactivée'}</div>
          </div>
          {runtimeStatus?.environment && (
            <div className="border-t border-[#263042] pt-2 space-y-2 text-[11px] text-[#cbd5e1]">
              <div className="text-[#94a3b8]">Toutes les variables utilisées (secrets masqués)</div>
              <div className="grid gap-1">
                {(runtimeStatus.environment.variables || []).map((variable) => (
                  <div key={variable.name} className="flex items-center justify-between gap-3 rounded bg-[#111827] px-2 py-1">
                    <code className="text-[#93c5fd]">{variable.name}</code>
                    <span className={variable.configured ? 'text-emerald-400' : 'text-amber-400'}>
                      {variable.configured ? (variable.value || 'configurée') : 'non définie'}
                    </span>
                  </div>
                ))}
              </div>
              {!runtimeStatus.environment.variables?.length && <div className="text-[#64748b]">Aucune variable relay détectée.</div>}
              <p className="text-[10px] text-[#64748b]">Les variables Vercel ne peuvent pas être modifiées depuis le navigateur. Les relais et la clé ScraperAPI ci-dessous sont la configuration runtime sauvegardable.</p>
            </div>
          )}
          {runtimeStatus?.relays?.length > 0 && (
            <div className="space-y-1 border-t border-[#263042] pt-2">
              {runtimeStatus.relays.map((relay, index) => (
                <div key={`${relay.url}-${index}`} className="truncate text-[11px] text-[#93c5fd]" title={relay.url}>
                  Relay {index + 1}: {relay.url} {relay.key ? `(${relay.key})` : ''}
                </div>
              ))}
            </div>
          )}
          {runtimeStatus?.last && <pre className="overflow-auto text-[10px] text-[#64748b]">{JSON.stringify(runtimeStatus.last, null, 2)}</pre>}
        </section>

        <div className="flex flex-wrap gap-2">
          {['zt_org.php', 'relay.php', 'relay.py', 'README.md'].map((f) => (
            <a key={f} href={relayFileUrl(f)} data-testid={`download-${f.replace('.', '-')}`}
               className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-[#263042] text-[#cbd5e1] hover:border-[#3b82f6] transition-colors">
              <Download size={12} /> {f}
            </a>
          ))}
        </div>

        {!settings ? (
          <div className="flex gap-2">
            <input data-testid="admin-key-input" type="password" className={inputCls} placeholder="Clé admin"
                   value={adminKey} onChange={(e) => setAdminKey(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && unlock()} />
            <button data-testid="admin-unlock-btn" onClick={unlock} disabled={!adminKey || busy}
                    className={`${btnCls} bg-[#3b82f6] text-white hover:bg-[#2563eb]`}>
              {busy === 'load' ? <Loader2 size={14} className="animate-spin" /> : <KeyRound size={14} />} Déverrouiller
            </button>
          </div>
        ) : (
          <div className="space-y-5">
            <section className="space-y-2">
              <div className="flex items-center justify-between gap-3">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-[#94a3b8]">Configuration du relay</h3>
                <span className="text-[10px] text-[#64748b]">Enregistrer applique les changements</span>
              </div>
              <p className="text-[11px] text-[#64748b]">Les variables Vercel restent protégées. Modifiez ici les relais et la clé ScraperAPI utilisés par l&apos;application, puis cliquez sur Enregistrer.</p>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-[#94a3b8]">Relais (prioritaires)</h3>
              <RelayList relays={settings.relays} onChange={(relays) => setSettings({ ...settings, relays })} />
            </section>
            <section className="space-y-2">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-[#94a3b8]">Clé ScraperAPI (optionnel, 1000 req/mois gratuites)</h3>
              <input data-testid="scraperapi-key-input" className={inputCls} placeholder="clé API scraperapi.com"
                     value={settings.scraperapi_key} onChange={(e) => setSettings({ ...settings, scraperapi_key: e.target.value })} />
            </section>
            <label className="flex items-center justify-between text-xs text-[#cbd5e1]">
              Tenter aussi la connexion directe
              <Switch data-testid="direct-switch" checked={settings.direct} onCheckedChange={(direct) => setSettings({ ...settings, direct })} />
            </label>
            <div className="flex gap-2">
              <button data-testid="sources-save-btn" onClick={save} disabled={!!busy} className={`${btnCls} bg-[#3b82f6] text-white hover:bg-[#2563eb]`}>
                {busy === 'save' && <Loader2 size={14} className="animate-spin" />} Enregistrer
              </button>
              <button data-testid="sources-test-btn" onClick={test} disabled={!!busy} className={`${btnCls} border border-[#263042] text-[#cbd5e1] hover:border-[#3b82f6]`}>
                {busy === 'test' && <Loader2 size={14} className="animate-spin" />} Tester sur le .org
              </button>
            </div>
            <SourceTestResults results={testResults} />
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
