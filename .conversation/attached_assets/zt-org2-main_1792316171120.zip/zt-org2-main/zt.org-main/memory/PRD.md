# ZT Search — Zone-Téléchargement.org Aggregator

## Original Problem Statement
Application FastAPI + React pour rechercher et lister le contenu de zone-telechargement.org.
Focused sur le domaine .org avec contournement Cloudflare (curl_cffi + proxies SOCKS5).

## Architecture
- **Backend**: FastAPI (port 8001) | MongoDB | Python
  - `server.py` — routes API, scraping, parsing
  - `fetcher.py` — HTTP avec proxies + curl_cffi impersonation
  - `proxy_manager.py` — pool de proxies SOCKS5 gratuits
- **Frontend**: React (port 3000) | Tailwind | react-router-dom v7
  - `App.js` — Routes BrowserRouter (LinksPage + MainView)
  - `api/zt.js` — client API
  - `components/LinksPage.jsx` — page /liens/film/:id
- **Base URL**: `https://www.zone-telechargement.org`

## Implemented Features (as of 2026-10)

### Core
- Recherche full-text via DLE engine (POST /index.php?do=search) — 2 pages en parallèle
- Détail page : extraction des liens par blocs `<div style="font-weight:bold">HOST</div>` + `<img src='/img/HOST.png'>` + `btnToLink`
- Catégories : Films, Séries, Animes, Jeux, Musiques, Ebooks, Logiciels, Docs, Émissions, Spectacles, Concerts, Sport
- Proxy d'images (GET /api/img?url=...) pour éviter les restrictions CDN
- Pool de proxies SOCKS5 auto-géré (proxy_manager.py)

### API Endpoints
- `GET /api/search?q={query}&type={type}` — recherche (2 pages parallèles)
- `GET /api/detail?urls={url1,url2}` — détail avec liens de téléchargement
- `GET /api/latest?type={type}&limit={n}` — dernières additions (parallel fetch)
- `GET /api/liens/film/{tmdb_id}[?title={titre}]` — liens JSON par ID TMDB film
- `GET /api/liens/serie/{tmdb_id}[?title={titre}]` — liens JSON par ID TMDB série
- `GET /api/img?url={encoded_url}` — proxy images
- `GET /api/status` — statut proxy pool

### Frontend Routes
- `/` — page d'accueil avec "Dernières additions" par catégorie
- `/liens/film/:tmdbId` — page JSON liens film (fallback formulaire titre si pas de clé TMDB)
- `/liens/serie/:tmdbId` — page JSON liens série

## Scraper Detail Page — Structure HTML (current .org)
Le site utilise deux patterns pour les liens :
1. `<div style="font-weight:bold">HOST NAME</div>` + `<a href="...">` (ancien)
2. `<img src='/img/HOSTNAME.png'>` + `<a class="btnToLink" href="//zoneurs.net/...">` (actuel)

Le pattern 2 est le principal. `zoneurs.net/?url=BASE64` est décodé automatiquement.

## Environment Variables
- `MONGO_URL` — MongoDB connection string
- `DB_NAME` — Database name
- `CORS_ORIGINS` — CORS allowed origins
- `ADMIN_KEY` — Admin key for source config
- `TMDB_API_KEY` — (optionnel) Clé API TMDB pour résolution ID→titre automatique
  - Sans clé : formulaire manuel de titre sur la page /liens/film/:id
  - Obtenir sur : https://www.themoviedb.org/settings/api (gratuit)

## Pending / Backlog

### P1 - Improvements
- Ajouter cache Redis/MongoDB pour les résultats latest (TTL 5min)
- Pagination des résultats de recherche (frontend)
- Streaming links : détecter et tester les hébergeurs de streaming

### P2 - Nice to have  
- Mode hors-ligne avec cache local des dernières recherches
- Notifications pour les nouvelles sorties par titre favori
- Afficher note TMDB + synopsis sur les cards (avec clé TMDB)

## Known Limitations
- Posters parfois indisponibles (restrictions hotlink CDN .org)
- Pool de proxies vide au démarrage (~2min de warmup)
- Résultats search limités à ~10-20 items (2 pages DLE)
- TV/séries latest peut être lent si proxies surchargés
