"""Backend API tests for ZT Search – free rotating proxy pool bypass of zone-telechargement.org."""
import os
import pytest
import requests

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')
assert BASE_URL, "REACT_APP_BACKEND_URL must be set"
ADMIN_KEY = os.environ.get('TEST_ADMIN_KEY', 'w7_pULpcI4plWMT6')

TIMEOUT_SEARCH = 90
TIMEOUT_DETAIL = 120


# ─── /api/status ─────────────────────────────────────────────
class TestStatus:
    def test_status_ok(self):
        r = requests.get(f"{BASE_URL}/api/status", timeout=20)
        assert r.status_code == 200
        d = r.json()
        assert 'proxyPool' in d, "proxyPool missing"
        assert isinstance(d['proxyPool'], dict)
        assert d['proxyPool'].get('pool', 0) > 0, f"proxy pool empty: {d['proxyPool']}"
        # structural fields
        assert 'relays' in d and isinstance(d['relays'], list)
        assert 'direct' in d


# ─── /api/settings auth ──────────────────────────────────────
class TestSettingsAuth:
    def test_get_settings_no_key(self):
        r = requests.get(f"{BASE_URL}/api/settings", timeout=15)
        assert r.status_code == 401

    def test_get_settings_bad_key(self):
        r = requests.get(f"{BASE_URL}/api/settings",
                         headers={'X-Admin-Key': 'wrong'}, timeout=15)
        assert r.status_code == 401

    def test_get_settings_ok(self):
        r = requests.get(f"{BASE_URL}/api/settings",
                         headers={'X-Admin-Key': ADMIN_KEY}, timeout=15)
        assert r.status_code == 200
        d = r.json()
        assert 'relays' in d and 'scraperapi_key' in d and 'direct' in d


# ─── /api/search ────────────────────────────────────────────
class TestSearch:
    def test_search_movie(self):
        r = requests.get(f"{BASE_URL}/api/search",
                         params={'q': 'avatar', 'type': 'movie'},
                         timeout=TIMEOUT_SEARCH)
        assert r.status_code == 200
        d = r.json()
        assert d['query'] == 'avatar'
        assert d['type'] == 'movie'
        assert d.get('blocked') is False, f"blocked unexpectedly: {d.get('errors')}"
        results = d.get('results', [])
        assert len(results) > 0, "no results"
        first = results[0]
        for k in ('title', 'poster', 'quality', 'lang', 'pageUrls'):
            assert k in first, f"missing key {k} in result"
        assert isinstance(first['pageUrls'], list) and len(first['pageUrls']) >= 1
        assert first['poster'].startswith('http'), f"poster not http url: {first['poster']}"

    def test_search_tv_grouped(self):
        r = requests.get(f"{BASE_URL}/api/search",
                         params={'q': 'breaking bad', 'type': 'tv'},
                         timeout=TIMEOUT_SEARCH)
        assert r.status_code == 200
        d = r.json()
        assert d['type'] == 'tv'
        results = d.get('results', [])
        assert len(results) > 0, "no tv results"
        # grouped series should typically have multiple pageUrls (seasons)
        max_urls = max(len(r.get('pageUrls', [])) for r in results)
        assert max_urls >= 2, f"expected grouped seasons, max pageUrls was {max_urls}"


# ─── /api/detail ────────────────────────────────────────────
HOST_HINTS = ('turbobit', '1fichier', 'nitroflare', 'rapidgator',
              'uptobox', 'uqload', 'fileserve', 'ddownload',
              'mega.nz', 'mesfichiers')


class TestDetail:
    def test_detail_real_hosts(self):
        s = requests.get(f"{BASE_URL}/api/search",
                         params={'q': 'avatar', 'type': 'movie'},
                         timeout=TIMEOUT_SEARCH)
        assert s.status_code == 200
        results = s.json().get('results', [])
        assert results, "no search results to drive detail test"
        page_urls = results[0]['pageUrls'][:2]
        r = requests.get(f"{BASE_URL}/api/detail",
                         params={'urls': ','.join(page_urls)},
                         timeout=TIMEOUT_DETAIL)
        assert r.status_code == 200
        res = r.json().get('result', {})
        assert res.get('title')
        assert isinstance(res.get('qualities'), list) and len(res['qualities']) >= 1
        # Flatten all download links across qualities
        all_links = []
        for q in res['qualities']:
            for l in q.get('downloadLinks', []):
                all_links.append((l.get('host', ''), l.get('url', '')))
        assert all_links, "no download links at all"
        # No zoneurs.net redirect urls – they should have been resolved
        zoneurs = [u for _, u in all_links if 'zoneurs.net' in u]
        assert not zoneurs, f"unresolved zoneurs.net links: {zoneurs[:3]}"
        # At least one real file host must be present
        real = [(h, u) for h, u in all_links
                if any(hint in u.lower() for hint in HOST_HINTS)]
        assert real, f"no real file-host links; got: {[h for h,_ in all_links][:10]}"
