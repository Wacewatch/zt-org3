import asyncio, sys, re
from curl_cffi.requests import AsyncSession

TARGET = 'https://www.zone-telechargement.org/?p=films&search=avatar'


def load():
    out = []
    for f, scheme in [('/tmp/p1.txt', None), ('/tmp/p4.txt', 'http'), ('/tmp/p2.txt', 'http'), ('/tmp/p3.txt', 'socks5')]:
        for line in open(f):
            line = line.strip()
            if not line:
                continue
            if '://' not in line:
                line = f'{scheme}://{line}'
            out.append(line.replace('socks5://', 'socks5h://'))
    return list(dict.fromkeys(out))


async def probe(p, sem, stats):
    async with sem:
        try:
            async with AsyncSession(impersonate='chrome', proxy=p, timeout=12, verify=False) as s:
                r = await s.get(TARGET)
                t = r.text
                if r.status_code == 200 and 'cover_global' in t:
                    stats['ok'].append(p); print('OK', p, flush=True)
                elif 'you have been blocked' in t:
                    stats['blocked'] += 1
                elif 'Just a moment' in t:
                    stats['challenge'] += 1
                else:
                    stats['other'] += 1
        except Exception:
            stats['err'] += 1


async def main():
    ps = load()[: int(sys.argv[1]) if len(sys.argv) > 1 else 3000]
    stats = {'ok': [], 'blocked': 0, 'challenge': 0, 'other': 0, 'err': 0}
    sem = asyncio.Semaphore(300)
    await asyncio.gather(*(probe(p, sem, stats) for p in ps))
    print({k: (len(v) if isinstance(v, list) else v) for k, v in stats.items()})
    open('/tmp/ok_proxies.txt', 'w').write('\n'.join(stats['ok']))

asyncio.run(main())
