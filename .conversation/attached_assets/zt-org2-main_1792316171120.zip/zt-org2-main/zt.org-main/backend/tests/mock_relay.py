"""Dev only: simulates a working residential relay by serving .space mirror HTML for .org URLs."""
from fastapi import FastAPI, Query
from fastapi.responses import HTMLResponse
from curl_cffi.requests import AsyncSession
import uvicorn

app = FastAPI()


@app.get("/")
async def relay(url: str = Query(...), key: str = Query('')):
    if key != 'testkey':
        return HTMLResponse('bad key', status_code=401)
    async with AsyncSession(impersonate='chrome', timeout=20) as s:
        r = await s.get(url.replace('zone-telechargement.org', 'zone-telechargement.space'))
    return HTMLResponse(r.text.replace('zone-telechargement.space', 'zone-telechargement.org'), status_code=r.status_code)


if __name__ == '__main__':
    uvicorn.run(app, host='127.0.0.1', port=8788)
