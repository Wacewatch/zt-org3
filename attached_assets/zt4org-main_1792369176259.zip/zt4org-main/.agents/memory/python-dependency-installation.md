---
name: Python dependency installation
description: Installing the ZT Search backend dependencies in Replit development and deployment environments.
---

For development in this project, install the pinned backend requirements through Replit's Python package installation flow. Direct `uv pip install --python "$(command -v python)" -r ...` can fail when the selected interpreter is in the immutable Nix store. Keep dependency versions in `artifacts/zt-search/backend/requirements.txt`. Artifact production build and run commands resolve paths from the workspace root, so use repository-root paths there; leave development commands service-relative.

**Why:** the command targeting the Nix-store interpreter failed, while Replit's package installation flow installed the same pinned dependencies successfully for local preview. A production build also failed because it resolved `backend/requirements.txt` from the workspace root instead of the artifact directory.

**How to apply:** use Replit's Python package manager when preparing a development preview. For production, check the workspace-root path and the deployment interpreter separately before changing dependency versions.
